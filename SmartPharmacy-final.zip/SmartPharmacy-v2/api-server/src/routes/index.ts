import { Router, type Request, type Response, type NextFunction } from 'express'
import { z } from 'zod/v4'
import { drugService } from '../services/drug.service.js'
import { chatService } from '../services/chat.service.js'
import { ocrService } from '../services/ocr.service.js'
import { prescriptionService } from '../services/prescription.service.js'
import { allergyService } from '../services/allergy.service.js'
import { interactionService } from '../services/interaction.service.js'
import { inventoryService } from '../services/inventory.service.js'
import { pharmacyService } from '../services/pharmacy.service.js'

const router = Router()

const patientCtx = z.object({
  age: z.number().int().min(0).max(120).optional(),
  sex: z.enum(['male', 'female', 'other']).optional(),
  weightKg: z.number().min(1).max(400).optional(),
  allergies: z.array(z.string().max(60)).max(40).optional(),
  conditions: z.array(z.string().max(60)).max(40).optional(),
  currentMeds: z.array(z.string().max(120)).max(40).optional(),
}).optional()

const chatSchema = z.object({ message: z.string().min(1).max(4000), context: patientCtx })
const ocrSchema = z.object({ image_base64: z.string().min(1), mime: z.string().optional() })
const rxSchema = z.object({ meds: z.array(z.string().min(1).max(160)).min(1).max(12), context: patientCtx })
const allergySchema = z.object({ active_ingredient: z.string().min(1).max(160), allergens: z.array(z.string().max(80)).max(30) })
const interactionSchema = z.object({ items: z.array(z.object({ trade_name: z.string().min(1).max(120), active_ingredient: z.string().min(1).max(160) })).min(2).max(12) })
const forecastSchema = z.object({ trade_name: z.string().min(1).max(120), days: z.coerce.number().int().min(7).max(90).default(30) })
const reserveSchema = z.object({ pharmacy_id: z.number().int().positive(), items: z.array(z.object({ trade_name: z.string().min(1).max(160), qty: z.number().int().min(1).max(20).optional() })).min(1).max(20), context: patientCtx })

router.get('/healthz', (_req: Request, res: Response) => {
  res.json({ status: 'ok' })
})

router.get('/search', async (req: Request, res: Response, next: NextFunction) => {
  const q = String(req.query.q ?? '').trim()
  if (!q || q.length > 120) { res.status(400).json({ error: 'Invalid query' }); return }
  try {
    const results = await drugService.searchAll(q)
    res.json(results)
  } catch (e) { next(e) }
})

router.post('/chat', async (req: Request, res: Response, next: NextFunction) => {
  const p = chatSchema.safeParse(req.body)
  if (!p.success) { res.status(400).json({ error: 'Invalid request' }); return }
  try {
    const reply = await chatService.chat(p.data.message, p.data.context ?? undefined)
    res.json(reply)
  } catch (e) { next(e) }
})

router.post('/ocr', async (req: Request, res: Response, next: NextFunction) => {
  const reqAny = req as Request & { files?: Record<string, { data: Buffer; mimetype: string }> }
  if (reqAny.files?.image) {
    const file = reqAny.files.image
    if (!String(file.mimetype ?? '').startsWith('image/')) { res.status(400).json({ error: 'Invalid file type' }); return }
    try { res.json(await ocrService.extractFromBuffer(file.data)) } catch (e) { next(e) }
    return
  }
  const p = ocrSchema.safeParse(req.body)
  if (!p.success) { res.status(400).json({ error: 'Invalid request' }); return }
  try { res.json(await ocrService.extractFromBase64(p.data.image_base64, p.data.mime ?? 'image/jpeg')) } catch (e) { next(e) }
})

router.post('/prescription/validate', async (req: Request, res: Response, next: NextFunction) => {
  const p = rxSchema.safeParse(req.body)
  if (!p.success) { res.status(400).json({ error: 'Invalid request' }); return }
  try { res.json(await prescriptionService.validate(p.data.meds, p.data.context ?? undefined)) } catch (e) { next(e) }
})

router.post('/allergy/check', (req: Request, res: Response, next: NextFunction) => {
  const p = allergySchema.safeParse(req.body)
  if (!p.success) { res.status(400).json({ error: 'Invalid request' }); return }
  try { res.json(allergyService.check(p.data.active_ingredient, p.data.allergens)) } catch (e) { next(e) }
})

router.post('/interactions/check', async (req: Request, res: Response, next: NextFunction) => {
  const p = interactionSchema.safeParse(req.body)
  if (!p.success) { res.status(400).json({ error: 'Invalid request' }); return }
  try { res.json({ hits: await interactionService.check(p.data.items) }) } catch (e) { next(e) }
})

router.get('/inventory/forecast', async (req: Request, res: Response, next: NextFunction) => {
  const p = forecastSchema.safeParse(req.query)
  if (!p.success) { res.status(400).json({ error: 'Invalid request' }); return }
  try {
    const points = await inventoryService.forecast(p.data.trade_name, p.data.days)
    res.json({ trade_name: p.data.trade_name, days: p.data.days, points })
  } catch (e) { next(e) }
})

router.get('/pharmacies', async (_req: Request, res: Response, next: NextFunction) => {
  try { res.json({ pharmacies: await pharmacyService.listAll() }) } catch (e) { next(e) }
})

router.post('/orders/reserve', async (req: Request, res: Response, next: NextFunction) => {
  const p = reserveSchema.safeParse(req.body)
  if (!p.success) { res.status(400).json({ error: 'Invalid request' }); return }
  try { res.json(await pharmacyService.reserve(p.data.pharmacy_id, p.data.items, p.data.context ?? undefined)) } catch (e) { next(e) }
})

export default router
