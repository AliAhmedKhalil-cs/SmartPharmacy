import express, { type Express, type Request, type Response, type NextFunction } from 'express'
import cors from 'cors'
import pinoHttp from 'pino-http'
import fileUpload from 'express-fileupload'
import router from './routes/index.js'
import { logger } from './lib/logger.js'
import { databaseService } from './lib/database.js'

const app: Express = express()

databaseService.ensureCoreTables().catch(err => {
  logger.error({ err }, 'Database initialization failed — check DATABASE_URL in .env')
  process.exit(1)
})

app.use(pinoHttp({
  logger,
  serializers: {
    req(req) { return { id: req.id, method: req.method, url: req.url?.split('?')[0] } },
    res(res) { return { statusCode: res.statusCode } },
  },
}))

app.use(cors())
app.use(express.json({ limit: '50mb' }))
app.use(express.urlencoded({ extended: true, limit: '50mb' }))
app.use(fileUpload({ createParentPath: true, limits: { fileSize: 50 * 1024 * 1024 } }))

app.use('/api', router)

app.use((err: unknown, _req: Request, res: Response, _next: NextFunction) => {
  const message = err instanceof Error
    ? (err.message || err.constructor.name || 'Unknown error')
    : String(err) || 'Internal server error'
  const code = (err as { code?: string }).code
  const detail = (err as { detail?: string }).detail
  const status = (err as { status?: number }).status ?? 500
  logger.error({ err, code, detail }, message)
  res.status(status).json({
    error: message,
    ...(process.env.NODE_ENV !== 'production' && code ? { code } : {}),
    ...(process.env.NODE_ENV !== 'production' && detail ? { detail } : {}),
  })
})

export default app
