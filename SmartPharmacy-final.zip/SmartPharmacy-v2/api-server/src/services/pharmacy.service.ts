import { db } from '../lib/database.js'

interface Pharmacy {
  id: number
  name: string
  address?: string | null
  phone?: string | null
  gps_lat?: number | null
  gps_lng?: number | null
  logo_url?: string | null
}

interface OrderItem {
  trade_name: string
  qty?: number
}

interface OrderResultItem {
  trade_name: string
  qty: number
  unit_price: number | null
  available: boolean
}

interface PatientContext {
  age?: number
  sex?: string
  weightKg?: number
  allergies?: string[]
  conditions?: string[]
  currentMeds?: string[]
}

interface ReserveOrderResponse {
  ok: boolean
  order_code: string
  pharmacy_id: number
  items: OrderResultItem[]
  total: number
}

class PharmacyService {
  private static instance: PharmacyService

  static getInstance(): PharmacyService {
    if (!PharmacyService.instance) {
      PharmacyService.instance = new PharmacyService()
    }
    return PharmacyService.instance
  }

  async listAll(): Promise<Pharmacy[]> {
    return db.queryRows<Pharmacy>(
      'SELECT id, name, address, phone, gps_lat, gps_lng, logo_url FROM pharmacies ORDER BY id ASC LIMIT 50'
    )
  }

  private generateOrderCode(): string {
    const part = () => Math.random().toString(36).slice(2, 6).toUpperCase()
    return `SP-${part()}-${part()}`
  }

  async reserve(pharmacyId: number, items: OrderItem[], ctx?: PatientContext): Promise<ReserveOrderResponse> {
    const code = this.generateOrderCode()
    const context = ctx ?? {}

    const row = await db.queryRow<{ id: number }>(
      `INSERT INTO orders(order_code, pharmacy_id, created_at, status, patient_age, patient_sex,
        patient_weight, patient_allergies, patient_conditions, patient_current_meds)
       VALUES ($1,$2,NOW(),$3,$4,$5,$6,$7,$8,$9) RETURNING id`,
      [
        code, pharmacyId, 'reserved',
        context.age ?? null, context.sex ?? null, context.weightKg ?? null,
        JSON.stringify(context.allergies ?? []),
        JSON.stringify(context.conditions ?? []),
        JSON.stringify(context.currentMeds ?? []),
      ]
    )

    const orderId = row?.id
    const resultItems: OrderResultItem[] = []

    for (const item of items) {
      const qty = item.qty ?? 1
      const stock = await db.queryRow<{ price: string; qty: string }>(
        `SELECT s.price::text, s.stock_quantity::text as qty
         FROM pharmacy_stock s
         WHERE s.pharmacy_id = $1 AND LOWER(s.drug_trade_name) LIKE $2
         ORDER BY s.stock_quantity DESC LIMIT 1`,
        [pharmacyId, `%${item.trade_name.toLowerCase()}%`]
      )

      const available = stock && parseInt(stock.qty ?? '0', 10) > 0
      const unitPrice = stock ? parseFloat(stock.price ?? '0') : null

      await db.query(
        'INSERT INTO order_items(order_id, trade_name, qty, unit_price, available) VALUES ($1,$2,$3,$4,$5)',
        [orderId, item.trade_name, qty, unitPrice, !!available]
      )

      resultItems.push({ trade_name: item.trade_name, qty, unit_price: unitPrice, available: !!available })
    }

    const total = resultItems.reduce(
      (sum, x) => sum + (x.available && x.unit_price ? x.unit_price * x.qty : 0),
      0
    )

    return { ok: true, order_code: code, pharmacy_id: pharmacyId, items: resultItems, total }
  }
}

export const pharmacyService = PharmacyService.getInstance()
