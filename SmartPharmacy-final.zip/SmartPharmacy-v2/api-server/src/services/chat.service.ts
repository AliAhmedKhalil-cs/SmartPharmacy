import { geminiService } from './gemini.service.js'

interface PatientContext {
  age?: number
  sex?: string
  weightKg?: number
  allergies?: string[]
  conditions?: string[]
  currentMeds?: string[]
}

interface ChatReply {
  reply: string
  provider: string
}

class ChatService {
  private static instance: ChatService

  static getInstance(): ChatService {
    if (!ChatService.instance) {
      ChatService.instance = new ChatService()
    }
    return ChatService.instance
  }

  private buildSystemPrompt(): string {
    return [
      'أنت مساعد صيدلي افتراضي ذكي. لا تقدم تشخيص ولا جرعات شخصية.',
      'قدّم معلومات عامة آمنة: استخدام، تداخلات، حساسية، تخزين، نصائح نمط حياة.',
      'لو في أعراض خطيرة أو شك في حساسية شديدة: وجّه لطبيب/طوارئ فورًا.',
      'اكتب بالعربي المصري البسيط وبشكل مختصر ومفيد.',
      'استخدم نقاط مرتبة وعناوين واضحة لتسهيل القراءة.',
    ].join('\n')
  }

  private buildProfileSection(ctx?: PatientContext): string {
    if (!ctx) return ''
    const parts: string[] = []
    if (ctx.age !== undefined) parts.push(`العمر: ${ctx.age} سنة`)
    if (ctx.sex) parts.push(`النوع: ${ctx.sex === 'male' ? 'ذكر' : ctx.sex === 'female' ? 'أنثى' : 'غير محدد'}`)
    if (ctx.weightKg !== undefined) parts.push(`الوزن: ${ctx.weightKg} كجم`)
    if (ctx.allergies?.length) parts.push(`الحساسية من: ${ctx.allergies.join('، ')}`)
    if (ctx.conditions?.length) parts.push(`الحالات الصحية: ${ctx.conditions.join('، ')}`)
    if (ctx.currentMeds?.length) parts.push(`الأدوية الحالية: ${ctx.currentMeds.join('، ')}`)
    return parts.length ? `\n\nملف المريض:\n${parts.join('\n')}` : ''
  }

  private fallbackAnswer(message: string, ctx?: PatientContext): string {
    const m = message.toLowerCase().trim()
    const profile = this.buildProfileSection(ctx)

    if (/جرعة|dose|كم مل|كام قرص/.test(m)) {
      return `مقدرش أحدد جرعة شخصية هنا. اكتب اسم الدواء وتركيزه وسنك/وزنك وأشرح الجرعات العامة مع تحذيرات مهمة.${profile}`
    }
    if (/قهوة|coffee|كافيين/.test(m)) {
      return `القهوة ممكن تزود تهيّج المعدة مع المسكنات، وممكن تزود خفقان مع أدوية البرد. اكتب اسم الدواء وأقولك أدق.${profile}`
    }
    if (/مضاد حيوي|antibiotic/.test(m)) {
      return `المضاد الحيوي لازم يكتمل للمدة المحددة حتى لو اتحسّنت. لو ظهرت حساسية شديدة أوقفه وروح طوارئ.${profile}`
    }
    if (/صيام|رمضان|افطر/.test(m)) {
      return `في الصيام: بنقسّم الجرعات بين الإفطار والسحور. اكتب اسم الدواء وعدد الجرعات وأساعدك.${profile}`
    }
    return `قولّي اسم الدواء أو صور الروشتة وأنا أساعدك: بدائل، تحذيرات، تداخلات.${profile}`
  }

  async chat(message: string, ctx?: PatientContext): Promise<ChatReply> {
    const system = this.buildSystemPrompt()
    const profile = this.buildProfileSection(ctx)
    const prompt = `${system}\n\nسؤال المستخدم: ${message}${profile}`

    if (!geminiService.isConfigured()) {
      return { reply: this.fallbackAnswer(message, ctx), provider: 'fallback' }
    }

    try {
      const reply = await geminiService.generateText(prompt)
      return { reply, provider: 'gemini' }
    } catch {
      const useFallback = String(process.env.CHAT_FALLBACK ?? 'on').toLowerCase() !== 'off'
      if (useFallback) {
        return { reply: this.fallbackAnswer(message, ctx), provider: 'fallback' }
      }
      throw new Error('AI service temporarily unavailable')
    }
  }
}

export const chatService = ChatService.getInstance()
