import { drugService } from './drug.service.js'
import { interactionService } from './interaction.service.js'
import { allergyService } from './allergy.service.js'

interface PatientContext {
  age?: number
  sex?: string
  weightKg?: number
  allergies?: string[]
  conditions?: string[]
  currentMeds?: string[]
}

interface ResolvedItem {
  input: string
  match: {
    drug_id: number
    trade_name: string
    active_ingredient: string
    therapeutic_group?: string
    avg_price?: number
    form?: string
  } | null
}

type FlagLevel = 'info' | 'warn' | 'danger'

interface RxFlag {
  level: FlagLevel
  code: string
  title: string
  message: string
  related?: string[]
}

interface Alternative {
  trade_name: string
  active_ingredient: string
  avg_price?: number
}

interface ValidationResult {
  items: ResolvedItem[]
  flags: RxFlag[]
  interactions: unknown[]
  allergy: { hits: unknown[] }
  alternatives: Record<string, Alternative[]>
}

class PrescriptionService {
  private static instance: PrescriptionService

  static getInstance(): PrescriptionService {
    if (!PrescriptionService.instance) {
      PrescriptionService.instance = new PrescriptionService()
    }
    return PrescriptionService.instance
  }

  private normalize(s: string): string {
    return String(s ?? '').toLowerCase().trim()
  }

  private hasAny(texts: string[] | undefined, needles: string[]): boolean {
    const hay = (texts ?? []).map(t => this.normalize(t))
    return needles.some(n => hay.some(h => h.includes(this.normalize(n))))
  }

  private async resolveItems(inputs: string[]): Promise<ResolvedItem[]> {
    const clean = inputs.map(x => String(x ?? '').trim()).filter(Boolean).slice(0, 12)
    const resolved: ResolvedItem[] = []

    for (const input of clean) {
      const hits = await drugService.search(input)
      const best = hits[0] ?? null
      resolved.push({
        input,
        match: best ? {
          drug_id: best.drug_id,
          trade_name: best.trade_name,
          active_ingredient: best.active_ingredient,
          therapeutic_group: (best as { therapeutic_group?: string }).therapeutic_group,
          avg_price: (best as { avg_price?: number }).avg_price,
          form: (best as { form?: string }).form,
        } : null,
      })
    }

    return resolved
  }

  private buildGeneralFlags(items: ResolvedItem[]): RxFlag[] {
    const unknown = items.filter(x => !x.match)
    if (!unknown.length) return []
    return [{
      level: 'info',
      code: 'UNKNOWN_ITEMS',
      title: 'عناصر غير مؤكدة',
      message: 'في أدوية مش قدرنا نحددها بدقة. جرّب تكتب الاسم بشكل أوضح.',
      related: unknown.map(x => x.input),
    }]
  }

  private buildDuplicateFlags(items: ResolvedItem[]): RxFlag[] {
    const byActive = new Map<string, ResolvedItem[]>()
    for (const it of items) {
      const a = this.normalize(it.match?.active_ingredient ?? '')
      if (!a) continue
      const list = byActive.get(a) ?? []
      list.push(it)
      byActive.set(a, list)
    }

    const flags: RxFlag[] = []
    for (const [active, list] of byActive.entries()) {
      if (list.length < 2) continue
      flags.push({
        level: 'warn',
        code: 'DUP_ACTIVE',
        title: 'تكرار نفس المادة الفعالة',
        message: `في أكتر من دواء بنفس المادة الفعالة (${active}). ده ممكن يسبب جرعة زيادة.`,
        related: list.map(x => x.match?.trade_name ?? x.input),
      })
    }
    return flags
  }

  private buildConditionFlags(items: ResolvedItem[], ctx?: PatientContext): RxFlag[] {
    const flags: RxFlag[] = []
    const acts = items.map(x => this.normalize(x.match?.active_ingredient ?? '')).filter(Boolean)

    const nsaids = ['ibuprofen', 'diclofenac', 'naproxen', 'ketoprofen', 'celecoxib', 'meloxicam']
    const hasNsaid = acts.some(a => nsaids.some(k => a.includes(k)))

    if (hasNsaid && this.hasAny(ctx?.conditions, ['ضغط', 'hypertension', 'kidney', 'كلى', 'قرحة', 'ulcer'])) {
      flags.push({
        level: 'warn',
        code: 'COND_NSAID',
        title: 'تنبيه مع المسكنات',
        message: 'لو عندك ضغط/مشاكل كلى/قرحة، بعض المسكنات ممكن تزود المخاطر. راجع صيدلي/طبيب.',
        related: items.filter(x => nsaids.some(k => this.normalize(x.match?.active_ingredient ?? '').includes(k))).map(x => x.match?.trade_name ?? x.input),
      })
    }

    const age = ctx?.age
    if (age !== undefined && age < 12 && acts.some(a => a.includes('aspirin'))) {
      flags.push({
        level: 'danger',
        code: 'PED_ASPIRIN',
        title: 'تحذير للأطفال',
        message: 'الأسبرين للأطفال أقل من 12 سنة غير مُفضل إلا بوصفة. راجع طبيب/صيدلي.',
      })
    }

    return flags
  }

  async validate(meds: string[], ctx?: PatientContext): Promise<ValidationResult> {
    const items = await this.resolveItems(meds)
    const known = items
      .filter(x => x.match?.active_ingredient)
      .map(x => ({ trade_name: x.match!.trade_name, active_ingredient: x.match!.active_ingredient }))

    const interactions = known.length >= 2 ? await interactionService.check(known) : []

    const allergyHits = ctx?.allergies?.length
      ? allergyService.checkMultiple(known, ctx.allergies)
      : []

    const flags: RxFlag[] = []
    flags.push(...this.buildGeneralFlags(items))
    flags.push(...this.buildDuplicateFlags(items))
    flags.push(...this.buildConditionFlags(items, ctx))

    if (allergyHits.length) {
      flags.push({
        level: 'danger',
        code: 'ALLERGY_HIT',
        title: 'تحذير حساسية',
        message: 'في أدوية ممكن تتعارض مع الحساسية المسجلة. راجع صيدلي/طبيب.',
        related: allergyHits.map(h => h.trade_name),
      })
    }

    if (interactions.length) {
      const hasHigh = interactions.some((x: { severity: string }) => x.severity === 'high')
      flags.push({
        level: hasHigh ? 'danger' : 'warn',
        code: 'INTERACTIONS',
        title: 'تداخلات دوائية محتملة',
        message: hasHigh
          ? 'في تداخلات خطيرة محتملة بين بعض الأدوية. راجع طبيب فورًا.'
          : 'في تداخلات محتملة بين بعض الأدوية. راجع صيدلي/طبيب.',
        related: (interactions as Array<{ a: { trade_name: string }; b: { trade_name: string } }>)
          .slice(0, 6)
          .map(x => `${x.a.trade_name} + ${x.b.trade_name}`),
      })
    }

    const alternatives: Record<string, Alternative[]> = {}
    for (const it of items) {
      if (!it.match?.active_ingredient) continue
      const alts = await drugService.findAlternatives(it.match.active_ingredient, it.match.trade_name, it.match.avg_price)
      alternatives[it.match.trade_name] = alts.map(a => ({
        trade_name: a.trade_name,
        active_ingredient: it.match!.active_ingredient,
        avg_price: a.avg_price,
      }))
    }

    return { items, flags, interactions, allergy: { hits: allergyHits }, alternatives }
  }
}

export const prescriptionService = PrescriptionService.getInstance()
