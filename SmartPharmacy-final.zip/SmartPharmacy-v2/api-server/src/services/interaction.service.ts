import { db } from '../lib/database.js'

type Severity = 'low' | 'medium' | 'high'

interface InteractionItem {
  trade_name: string
  active_ingredient: string
}

interface InteractionHit {
  a: InteractionItem
  b: InteractionItem
  severity: Severity
  summary: string
}

class InteractionService {
  private static instance: InteractionService

  static getInstance(): InteractionService {
    if (!InteractionService.instance) {
      InteractionService.instance = new InteractionService()
    }
    return InteractionService.instance
  }

  private normalize(s: string): string {
    return s.toLowerCase().trim()
  }

  private severityScore(s: Severity): number {
    const map: Record<Severity, number> = { high: 3, medium: 2, low: 1 }
    return map[s] ?? 0
  }

  async check(items: InteractionItem[]): Promise<InteractionHit[]> {
    if (items.length < 2) return []

    const hits: InteractionHit[] = []

    for (let i = 0; i < items.length; i++) {
      for (let j = i + 1; j < items.length; j++) {
        const a = items[i]
        const b = items[j]
        const aAct = this.normalize(a.active_ingredient)
        const bAct = this.normalize(b.active_ingredient)

        const rule = await db.queryRow<{ severity: string; summary: string }>(
          `SELECT severity, summary FROM interaction_rules
           WHERE (LOWER(a_active) = $1 AND LOWER(b_active) = $2)
              OR (LOWER(a_active) = $2 AND LOWER(b_active) = $1)
           LIMIT 1`,
          [aAct, bAct]
        )

        if (rule) {
          hits.push({ a, b, severity: rule.severity as Severity, summary: rule.summary })
        }
      }
    }

    return hits.sort((x, y) => this.severityScore(y.severity) - this.severityScore(x.severity))
  }
}

export const interactionService = InteractionService.getInstance()
