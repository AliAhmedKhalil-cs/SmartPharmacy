import { db } from '../lib/database.js'

interface ForecastPoint {
  date: string
  expected_demand: number
}

class InventoryService {
  private static instance: InventoryService

  static getInstance(): InventoryService {
    if (!InventoryService.instance) {
      InventoryService.instance = new InventoryService()
    }
    return InventoryService.instance
  }

  private toIso(d: Date): string {
    return d.toISOString().slice(0, 10)
  }

  private seasonMultiplier(month: number): number {
    if ([12, 1, 2].includes(month)) return 1.25
    if ([6, 7, 8].includes(month)) return 1.05
    return 1.0
  }

  private round1(n: number): number {
    return Math.round(n * 10) / 10
  }

  async forecast(tradeName: string, days: number): Promise<ForecastPoint[]> {
    const rows = await db.queryRows<{ qty: string }>(
      `SELECT SUM(qty)::text as qty
       FROM sales_daily
       WHERE LOWER(drug_trade_name) LIKE $1
       GROUP BY sold_date
       ORDER BY sold_date DESC
       LIMIT 120`,
      [`%${tradeName.toLowerCase()}%`]
    )

    const values = rows.map(r => Number(r.qty ?? 0)).filter(x => x >= 0)
    const avg = values.length > 0 ? values.reduce((a, b) => a + b, 0) / values.length : 3

    const today = new Date()
    const points: ForecastPoint[] = []

    for (let i = 1; i <= days; i++) {
      const d = new Date(today)
      d.setDate(d.getDate() + i)
      const seasonal = this.seasonMultiplier(d.getMonth() + 1)
      points.push({ date: this.toIso(d), expected_demand: this.round1(avg * seasonal) })
    }

    return points
  }
}

export const inventoryService = InventoryService.getInstance()
