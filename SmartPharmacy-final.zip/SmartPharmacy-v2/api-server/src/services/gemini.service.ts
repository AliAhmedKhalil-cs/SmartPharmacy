import { logger } from '../lib/logger.js'

class GeminiService {
  private static instance: GeminiService
  private readonly apiKey: string
  private readonly models: string[] = [
    'gemini-2.5-flash',
    'gemini-2.0-flash',
    'gemini-1.5-flash',
    'gemini-1.5-pro',
  ]

  constructor() {
    this.apiKey = process.env.GEMINI_API_KEY ?? ''
  }

  static getInstance(): GeminiService {
    if (!GeminiService.instance) {
      GeminiService.instance = new GeminiService()
    }
    return GeminiService.instance
  }

  isConfigured(): boolean {
    return this.apiKey.length > 0
  }

  async generate(text: string, imageBuffer?: Buffer): Promise<string> {
    if (!this.apiKey) throw new Error('GEMINI_API_KEY not configured')

    let lastError: unknown
    for (const model of this.models) {
      try {
        const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${this.apiKey}`
        const parts: unknown[] = [{ text }]
        if (imageBuffer) {
          parts.push({ inline_data: { mime_type: 'image/jpeg', data: imageBuffer.toString('base64') } })
        }

        const controller = new AbortController()
        const timeoutId = setTimeout(() => controller.abort(), 15000)

        const response = await fetch(url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ contents: [{ parts }] }),
          signal: controller.signal,
        })
        clearTimeout(timeoutId)

        if (!response.ok) {
          const bodyText = await response.text().catch(() => '')
          if (response.status === 429) {
            await new Promise(r => setTimeout(r, 1000))
            continue
          }
          if (response.status === 401 || response.status === 403 || /API Key not found|API_KEY_INVALID/i.test(bodyText)) {
            throw new Error('Invalid GEMINI_API_KEY')
          }
          throw new Error(`HTTP ${response.status}: ${bodyText.slice(0, 100)}`)
        }

        const data = await response.json() as { candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }> }
        const out = data?.candidates?.[0]?.content?.parts?.[0]?.text
        if (typeof out === 'string' && out.trim()) return out
      } catch (e) {
        lastError = e
        logger.warn({ model, err: e }, 'Gemini model failed, trying next')
      }
    }

    throw lastError instanceof Error ? lastError : new Error('All Gemini models failed')
  }

  async generateText(prompt: string): Promise<string> {
    return this.generate(prompt)
  }

  async analyzeImage(prompt: string, imageBuffer: Buffer): Promise<string> {
    return this.generate(prompt, imageBuffer)
  }
}

export const geminiService = GeminiService.getInstance()
