import { db } from '../lib/database.js'

interface DrugRow {
  drug_id: number
  trade_name: string
  active_ingredient: string
  therapeutic_group?: string
  avg_price?: number
  form?: string
}

interface AlternativeDrug {
  trade_name: string
  avg_price?: number
}

interface PharmacyLocation {
  pharmacy_id: number
  name: string
  address: string
  price: number
}

interface CosmeticRow {
  id: number
  name: string
  brand?: string
  category?: string
  price?: number
  skin_type?: string
  description?: string
}

interface SearchResult extends DrugRow {
  type: 'medication' | 'cosmetic'
  description?: string
  alternatives: AlternativeDrug[]
  available_locations: PharmacyLocation[]
}

class DrugService {
  private static instance: DrugService

  static getInstance(): DrugService {
    if (!DrugService.instance) {
      DrugService.instance = new DrugService()
    }
    return DrugService.instance
  }

  async search(q: string): Promise<DrugRow[]> {
    if (!q.trim()) return []
    const pattern = `%${q.toLowerCase()}%`
    return db.queryRows<DrugRow>(
      `SELECT drug_id, trade_name, active_ingredient, therapeutic_group, avg_price, form
       FROM drugs
       WHERE LOWER(trade_name) LIKE $1 OR LOWER(active_ingredient) LIKE $1
       ORDER BY trade_name ASC LIMIT 20`,
      [pattern]
    )
  }

  async findAlternatives(activeIngredient: string, tradeName: string, avgPrice?: number): Promise<AlternativeDrug[]> {
    const active = (activeIngredient ?? '').trim().toLowerCase()
    if (!active) return []

    const price = Number.isFinite(avgPrice) ? Number(avgPrice) : null
    return db.queryRows<AlternativeDrug>(
      `SELECT trade_name, avg_price FROM drugs
       WHERE LOWER(active_ingredient) = $1 AND trade_name <> $2
         AND ($3::numeric IS NULL OR ABS(COALESCE(avg_price, 0) - $3) <= 20)
       ORDER BY ABS(COALESCE(avg_price, 0) - COALESCE($3, 0)) ASC
       LIMIT 6`,
      [active, tradeName, price]
    )
  }

  async getPharmacyLocations(tradeName: string): Promise<PharmacyLocation[]> {
    return db.queryRows<PharmacyLocation>(
      `SELECT p.id as pharmacy_id, p.name, p.address, s.price
       FROM pharmacy_stock s JOIN pharmacies p ON s.pharmacy_id = p.id
       WHERE LOWER(s.drug_trade_name) LIKE $1
       ORDER BY s.price ASC LIMIT 5`,
      [`%${tradeName.toLowerCase()}%`]
    )
  }

  async searchCosmetics(q: string): Promise<CosmeticRow[]> {
    const pattern = `%${q.toLowerCase()}%`
    return db.queryRows<CosmeticRow>(
      `SELECT * FROM cosmetics
       WHERE LOWER(name) LIKE $1 OR LOWER(brand) LIKE $1 OR LOWER(category) LIKE $1`,
      [pattern]
    )
  }

  async searchAll(q: string): Promise<SearchResult[]> {
    const [drugs, cosmetics] = await Promise.all([
      this.search(q),
      this.searchCosmetics(q),
    ])

    const enrichedDrugs = await Promise.all(
      drugs.map(async d => {
        const [alts, locations] = await Promise.all([
          this.findAlternatives(d.active_ingredient, d.trade_name, d.avg_price),
          this.getPharmacyLocations(d.trade_name),
        ])
        return {
          ...d,
          type: 'medication' as const,
          alternatives: alts,
          available_locations: locations,
        }
      })
    )

    const formattedCosmetics: SearchResult[] = cosmetics.map(c => ({
      drug_id: 0,
      trade_name: c.name,
      active_ingredient: c.brand ?? '',
      therapeutic_group: c.category,
      avg_price: c.price,
      form: c.skin_type,
      type: 'cosmetic' as const,
      description: c.description,
      alternatives: [],
      available_locations: [],
    }))

    return [...enrichedDrugs, ...formattedCosmetics]
  }
}

export const drugService = DrugService.getInstance()
