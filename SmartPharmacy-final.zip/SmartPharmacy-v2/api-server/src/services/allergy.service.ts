interface AllergyFlag {
  hit: boolean
  level: 'none' | 'warn'
  matched: string[]
}

class AllergyService {
  private static instance: AllergyService

  static getInstance(): AllergyService {
    if (!AllergyService.instance) {
      AllergyService.instance = new AllergyService()
    }
    return AllergyService.instance
  }

  private normalize(s: string): string {
    return s.toLowerCase().trim()
  }

  check(activeIngredient: string | null | undefined, allergens: string[]): AllergyFlag {
    const active = this.normalize(activeIngredient ?? '')
    if (!active) return { hit: false, level: 'none', matched: [] }

    const normalizedAllergens = allergens.map(a => this.normalize(a)).filter(Boolean)
    const matched = normalizedAllergens.filter(a => active.includes(a) || a.includes(active))

    if (matched.length === 0) return { hit: false, level: 'none', matched: [] }
    return { hit: true, level: 'warn', matched }
  }

  checkMultiple(drugs: Array<{ trade_name: string, active_ingredient: string }>, allergens: string[]) {
    return drugs.map(d => ({
      trade_name: d.trade_name,
      active_ingredient: d.active_ingredient,
      ...this.check(d.active_ingredient, allergens),
    })).filter(r => r.hit)
  }
}

export const allergyService = AllergyService.getInstance()
