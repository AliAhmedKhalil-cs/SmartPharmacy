import { geminiService } from './gemini.service.js'

class OcrService {
  private static instance: OcrService

  static getInstance(): OcrService {
    if (!OcrService.instance) {
      OcrService.instance = new OcrService()
    }
    return OcrService.instance
  }

  private parseNames(raw: string): string[] {
    return raw
      .replace(/[\[\]"`]/g, '')
      .split(',')
      .map(s => s.trim())
      .filter(s => s.length > 2)
  }

  async extractFromBase64(base64: string, mime: string): Promise<string[]> {
    if (!geminiService.isConfigured()) return []

    const imageBuffer = Buffer.from(base64, 'base64')
    const prompt = 'Extract trade names of medicines or cosmetics from this prescription image. Return as comma-separated list only. No explanations.'

    try {
      const text = await geminiService.analyzeImage(prompt, imageBuffer)
      return this.parseNames(text)
    } catch {
      return []
    }
  }

  async extractFromBuffer(buffer: Buffer): Promise<string[]> {
    if (!geminiService.isConfigured()) return []

    const prompt = 'Extract trade names of medicines or cosmetics from this prescription image. Return as comma-separated list only. No explanations.'

    try {
      const text = await geminiService.analyzeImage(prompt, buffer)
      return this.parseNames(text)
    } catch {
      return []
    }
  }
}

export const ocrService = OcrService.getInstance()
