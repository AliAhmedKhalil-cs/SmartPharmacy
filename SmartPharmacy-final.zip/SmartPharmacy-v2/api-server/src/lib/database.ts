import pg from 'pg'
import { logger } from './logger.js'

const { Pool } = pg

if (!process.env.DATABASE_URL) {
  throw new Error(
    '[database] DATABASE_URL is not set.\n' +
    'Create a .env file in api-server/ with:\n' +
    '  DATABASE_URL=postgresql://user:password@localhost:5432/smartpharmacy'
  )
}

class DatabaseService {
  private static instance: DatabaseService
  private pool: pg.Pool

  constructor() {
    this.pool = new Pool({ connectionString: process.env.DATABASE_URL })
    this.pool.on('error', (err: Error) => logger.error({ err }, 'pg pool error'))
  }

  static getInstance(): DatabaseService {
    if (!DatabaseService.instance) {
      DatabaseService.instance = new DatabaseService()
    }
    return DatabaseService.instance
  }

  async query<T extends pg.QueryResultRow = pg.QueryResultRow>(
    sql: string,
    values?: unknown[]
  ): Promise<pg.QueryResult<T>> {
    const client = await this.pool.connect()
    try {
      return await client.query<T>(sql, values)
    } finally {
      client.release()
    }
  }

  async queryRows<T extends pg.QueryResultRow = pg.QueryResultRow>(
    sql: string,
    values?: unknown[]
  ): Promise<T[]> {
    const res = await this.query<T>(sql, values)
    return res.rows
  }

  async queryRow<T extends pg.QueryResultRow = pg.QueryResultRow>(
    sql: string,
    values?: unknown[]
  ): Promise<T | undefined> {
    const rows = await this.queryRows<T>(sql, values)
    return rows[0]
  }

  async ensureCoreTables(): Promise<void> {
    await this.query(`
      CREATE TABLE IF NOT EXISTS drugs (
        drug_id SERIAL PRIMARY KEY,
        trade_name TEXT NOT NULL,
        active_ingredient TEXT,
        therapeutic_group TEXT,
        avg_price NUMERIC,
        form TEXT
      );
      CREATE INDEX IF NOT EXISTS idx_drugs_trade ON drugs(LOWER(trade_name));
      CREATE INDEX IF NOT EXISTS idx_drugs_active ON drugs(LOWER(active_ingredient));

      CREATE TABLE IF NOT EXISTS cosmetics (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        brand TEXT,
        category TEXT,
        price NUMERIC,
        skin_type TEXT,
        description TEXT
      );

      CREATE TABLE IF NOT EXISTS interaction_rules (
        id SERIAL PRIMARY KEY,
        a_active TEXT NOT NULL,
        b_active TEXT NOT NULL,
        severity TEXT NOT NULL,
        summary TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS sales_daily (
        id SERIAL PRIMARY KEY,
        pharmacy_id INTEGER,
        drug_trade_name TEXT NOT NULL,
        sold_date DATE NOT NULL,
        qty INTEGER NOT NULL
      );

      CREATE TABLE IF NOT EXISTS pharmacies (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        address TEXT,
        phone TEXT,
        gps_lat NUMERIC,
        gps_lng NUMERIC,
        logo_url TEXT
      );

      CREATE TABLE IF NOT EXISTS pharmacy_stock (
        id SERIAL PRIMARY KEY,
        pharmacy_id INTEGER,
        drug_trade_name TEXT,
        price NUMERIC,
        stock_quantity INTEGER DEFAULT 10,
        FOREIGN KEY(pharmacy_id) REFERENCES pharmacies(id)
      );

      CREATE TABLE IF NOT EXISTS orders (
        id SERIAL PRIMARY KEY,
        order_code TEXT NOT NULL,
        pharmacy_id INTEGER,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        status TEXT NOT NULL,
        patient_age INTEGER,
        patient_sex TEXT,
        patient_weight NUMERIC,
        patient_allergies TEXT,
        patient_conditions TEXT,
        patient_current_meds TEXT
      );

      CREATE TABLE IF NOT EXISTS order_items (
        id SERIAL PRIMARY KEY,
        order_id INTEGER,
        trade_name TEXT NOT NULL,
        qty INTEGER NOT NULL,
        unit_price NUMERIC,
        available BOOLEAN DEFAULT FALSE,
        FOREIGN KEY(order_id) REFERENCES orders(id)
      );
    `)

    await this.seedInteractions()
    await this.seedPharmacies()
    await this.seedDrugs()
  }

  private async seedInteractions(): Promise<void> {
    const res = await this.queryRow<{ c: string }>('SELECT COUNT(1) as c FROM interaction_rules')
    if (parseInt(res?.c ?? '0', 10) > 0) return

    const rules = [
      ['warfarin', 'ibuprofen', 'high', 'يزود خطر النزيف بشكل كبير'],
      ['warfarin', 'aspirin', 'high', 'يزود خطر النزيف بشكل كبير'],
      ['metformin', 'alcohol', 'medium', 'يزود خطر الحماض اللبني'],
      ['isotretinoin', 'vitamin a', 'medium', 'يزود السمية لفيتامين أ'],
      ['simvastatin', 'clarithromycin', 'high', 'يزود خطر اعتلال العضلات'],
      ['methotrexate', 'ibuprofen', 'high', 'يزود سمية الميثوتريكسات'],
      ['amiodarone', 'warfarin', 'high', 'يزود مفعول مميع الدم بشكل خطير'],
      ['ssri', 'tramadol', 'medium', 'خطر متلازمة السيروتونين'],
    ]

    for (const [a, b, sev, sum] of rules) {
      await this.query(
        'INSERT INTO interaction_rules(a_active, b_active, severity, summary) VALUES ($1,$2,$3,$4)',
        [a, b, sev, sum]
      )
    }
  }

  private async seedPharmacies(): Promise<void> {
    const res = await this.queryRow<{ c: string }>('SELECT COUNT(1) as c FROM pharmacies')
    if (parseInt(res?.c ?? '0', 10) > 0) return

    const pharmacies = [
      ['صيدلية العزبي - El Ezaby', '15 شارع قصر النيل، وسط البلد، القاهرة', '19011', 30.0444, 31.2357],
      ['صيدليات سيف - Seif Pharmacies', '22 شارع جامعة الدول، المهندسين، الجيزة', '19199', 30.0511, 31.2001],
      ['صيدلية مصر - Misr Pharmacy', '5 شارع التحرير، الدقي، الجيزة', '0227488800', 30.0459, 31.2089],
      ['صيدلية دواء - Dawaa', '33 شارع النصر، مدينة نصر، القاهرة', '0224027700', 30.0656, 31.3277],
      ['صيدلية رشدي - Rashdi', '18 شارع الهرم، الجيزة', '0237869900', 29.9875, 31.1919],
    ]

    for (const p of pharmacies) {
      await this.query(
        'INSERT INTO pharmacies (name, address, phone, gps_lat, gps_lng) VALUES ($1,$2,$3,$4,$5)',
        p
      )
    }
  }

  private async seedDrugs(): Promise<void> {
    const res = await this.queryRow<{ c: string }>('SELECT COUNT(1) as c FROM drugs')
    if (parseInt(res?.c ?? '0', 10) > 0) return

    const drugs = [
      ['باراسيتامول 500 - Paracetamol 500', 'paracetamol', 'مسكنات الألم', 15, 'أقراص'],
      ['برونامين - Brunaamine', 'paracetamol', 'مسكنات الألم', 18, 'أقراص'],
      ['ابيبروفين 400 - Ibuprofen 400', 'ibuprofen', 'مضادات الالتهاب', 22, 'أقراص'],
      ['فولتارين 50 - Voltaren 50', 'diclofenac', 'مضادات الالتهاب', 35, 'أقراص'],
      ['أموكسيل 500 - Amoxil 500', 'amoxicillin', 'مضادات حيوية', 45, 'كبسولات'],
      ['أوجمنتين 875 - Augmentin 875', 'amoxicillin+clavulanate', 'مضادات حيوية', 85, 'أقراص'],
      ['زيثروماكس 500 - Zithromax 500', 'azithromycin', 'مضادات حيوية', 95, 'أقراص'],
      ['سيبروفلوكساسين 500 - Ciprofloxacin 500', 'ciprofloxacin', 'مضادات حيوية', 55, 'أقراص'],
      ['لانسوبرازول 30 - Lansoprazole 30', 'lansoprazole', 'حماية المعدة', 48, 'كبسولات'],
      ['أوميبرازول 20 - Omeprazole 20', 'omeprazole', 'حماية المعدة', 30, 'كبسولات'],
      ['ميتفورمين 500 - Metformin 500', 'metformin', 'أدوية السكر', 12, 'أقراص'],
      ['جلوكوفاج 1000 - Glucophage 1000', 'metformin', 'أدوية السكر', 25, 'أقراص'],
      ['أملوديبين 5 - Amlodipine 5', 'amlodipine', 'أدوية القلب والضغط', 20, 'أقراص'],
      ['نورفاسك 10 - Norvasc 10', 'amlodipine', 'أدوية القلب والضغط', 45, 'أقراص'],
      ['أتورفاستاتين 20 - Atorvastatin 20', 'atorvastatin', 'خافضات الكوليسترول', 35, 'أقراص'],
      ['ليبيتور 40 - Lipitor 40', 'atorvastatin', 'خافضات الكوليسترول', 75, 'أقراص'],
      ['لوراتادين 10 - Loratadine 10', 'loratadine', 'مضادات الحساسية', 18, 'أقراص'],
      ['كلاريتين - Claritin', 'loratadine', 'مضادات الحساسية', 35, 'أقراص'],
      ['أسبرين 81 - Aspirin 81', 'aspirin', 'مسيلات الدم', 15, 'أقراص'],
      ['رانيتيدين 150 - Ranitidine 150', 'ranitidine', 'حماية المعدة', 20, 'أقراص'],
      ['بيزوبرولول 5 - Bisoprolol 5', 'bisoprolol', 'أدوية القلب والضغط', 28, 'أقراص'],
      ['انابريل 10 - Enalapril 10', 'enalapril', 'أدوية الضغط', 18, 'أقراص'],
      ['كلوبيدوجريل 75 - Clopidogrel 75', 'clopidogrel', 'مسيلات الدم', 55, 'أقراص'],
      ['سيتريزين 10 - Cetirizine 10', 'cetirizine', 'مضادات الحساسية', 15, 'أقراص'],
      ['ديكلوفيناك جيل - Diclofenac Gel', 'diclofenac', 'مضادات الالتهاب', 28, 'جيل'],
      ['فلوكسين 20 - Fluoxetine 20', 'fluoxetine', 'مضادات الاكتئاب', 45, 'كبسولات'],
      ['بيتاهستين 16 - Betahistine 16', 'betahistine', 'أدوية الأذن والدوخة', 55, 'أقراص'],
      ['ترامادول 50 - Tramadol 50', 'tramadol', 'مسكنات قوية', 25, 'أقراص'],
      ['بنتازوسين - Pentazocine', 'pentazocine', 'مسكنات قوية', 30, 'أقراص'],
      ['سيبروتيرون - Cyproterone', 'cyproterone', 'هرمونات', 65, 'أقراص'],
    ]

    for (const d of drugs) {
      await this.query(
        'INSERT INTO drugs (trade_name, active_ingredient, therapeutic_group, avg_price, form) VALUES ($1,$2,$3,$4,$5)',
        d
      )
    }

    const pharmacyRows = await this.queryRows<{ id: number }>('SELECT id FROM pharmacies')
    const drugRows = await this.queryRows<{ drug_id: number; trade_name: string; avg_price: number }>('SELECT drug_id, trade_name, avg_price FROM drugs')

    for (const drug of drugRows) {
      for (const ph of pharmacyRows) {
        const stock = Math.floor(Math.random() * 50) + 5
        const price = Math.round(Number(drug.avg_price) * (0.9 + Math.random() * 0.2))
        await this.query(
          'INSERT INTO pharmacy_stock (pharmacy_id, drug_trade_name, price, stock_quantity) VALUES ($1,$2,$3,$4)',
          [ph.id, drug.trade_name, price, stock]
        )
      }
    }
  }
}

export const databaseService = DatabaseService.getInstance()
export const db = databaseService
