# SmartPharmacy

مساعد صيدلي ذكي للسوق المصري يتيح البحث عن الأدوية، قراءة الروشتات بالذكاء الاصطناعي، فحص التداخلات الدوائية، والحجز في الصيدليات.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — API server (port 8080, routed via /api)
- `pnpm --filter @workspace/smartpharmacy run dev` — Frontend React app (port 23363, routed via /)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- Required env: `DATABASE_URL` — PostgreSQL connection string (auto-provisioned by Replit)
- Optional env: `GEMINI_API_KEY` — enables AI chat, OCR, and prescription validation features

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5 + OOP service classes (singleton pattern)
- DB: PostgreSQL via `pg` (raw queries, no ORM — auto-seeds drugs/pharmacies/interactions on first run)
- Validation: Zod (v4) on both client and server
- API codegen: Orval (from OpenAPI spec → React Query hooks + Zod schemas)
- Build: esbuild (ESM bundle for API server)
- Frontend: React 19 + Vite + Tailwind CSS + Wouter routing

## Where things live

```
artifacts/api-server/src/
  app.ts               — Express app setup (cors, fileupload, pino logging)
  routes/index.ts      — All API routes (healthz, search, chat, ocr, prescription, etc.)
  lib/database.ts      — DatabaseService singleton (PostgreSQL pool + auto-seeding)
  lib/logger.ts        — Pino logger
  services/
    gemini.service.ts  — Gemini AI integration with model fallback
    drug.service.ts    — Drug + cosmetic search, alternatives, pharmacy locations
    chat.service.ts    — AI pharmacy chat with fallback responses
    ocr.service.ts     — OCR prescription reading via Gemini Vision
    prescription.service.ts — Prescription validation (interactions + allergy + flags)
    allergy.service.ts — Drug allergy checking
    interaction.service.ts  — Drug interaction lookup (DB rules)
    inventory.service.ts    — Sales forecast with seasonal multipliers
    pharmacy.service.ts     — Pharmacy listing + order reservation

artifacts/smartpharmacy/src/
  App.tsx              — Root router (wouter) + React Query provider
  lib/api.ts           — Typed API client (fetch wrapper)
  hooks/use-patient.ts — Patient profile + cart (localStorage persistence)
  components/
    Layout.tsx         — Bottom nav bar with cart count badge
    DrugCard.tsx       — Drug search result card with alternatives/locations
  pages/
    HomePage.tsx       — Landing page with features grid and tips
    SearchPage.tsx     — Drug/cosmetic search with quick search chips
    ChatPage.tsx       — AI pharmacy chat with bubble UI
    OcrPage.tsx        — Prescription image OCR + add to cart
    PharmaciesPage.tsx — Pharmacy list + cart + order reservation
    ProfilePage.tsx    — Patient health profile (allergies, conditions, meds)

lib/api-spec/openapi.yaml — Single source of truth for all API contracts
```

## Architecture decisions

- **OOP service singletons**: All backend logic lives in classes with `static getInstance()`. No global functions or module-level state.
- **No comments in code**: Clean code philosophy throughout — zero inline comments.
- **PostgreSQL auto-seeding**: `DatabaseService.ensureCoreTables()` creates schema and seeds 30 drugs, 5 pharmacies, and interaction rules on first startup — no migration tool needed.
- **Gemini model fallback chain**: Tries gemini-2.5-flash → 2.0-flash → 1.5-flash → 1.5-pro before failing. Falls back to curated answers if GEMINI_API_KEY is missing.
- **RTL-first frontend**: `html { direction: rtl }` global, Cairo Arabic font, Egyptian dialect UI text throughout.
- **localStorage for patient profile**: Patient health data never leaves the device — stored in `sp_patient_profile` and `sp_cart` keys.

## Product

- **Drug search**: Full-text search on 30+ Egyptian market drugs by Arabic or English name, with alternatives and pharmacy locations
- **AI chat**: Gemini-powered pharmacy assistant in Egyptian Arabic with patient context awareness
- **OCR prescriptions**: Upload prescription images → Gemini Vision extracts drug names → add directly to cart
- **Drug interactions**: DB-driven interaction checking with severity levels (low/medium/high)
- **Allergy checking**: Cross-reference drugs against patient-recorded allergens
- **Prescription validation**: Multi-check (interactions + allergies + duplicates + condition-specific warnings)
- **Inventory forecasting**: Seasonal demand forecasting based on sales history
- **Pharmacy reservation**: Select pharmacy, manage cart, place order with confirmation code
- **Patient profile**: Persistent health profile (age, sex, weight, allergies, conditions, current meds)

## User preferences

- Zero comments in all code
- OOP architecture with service class singletons throughout backend
- Egyptian market focus: Arabic RTL UI, Egyptian dialect text, Egyptian pharmacy names
- Creative frontend design — not just functional but visually appealing

## Gotchas

- sqlite3/sqlite packages are removed — backend uses PostgreSQL only
- `GEMINI_API_KEY` is optional: chat/OCR/OCR features degrade gracefully to fallback
- Run `pnpm --filter @workspace/api-spec run codegen` after any OpenAPI spec change
- The `health.ts` route file is now superseded by `routes/index.ts` — both are mounted but `/healthz` in index.ts takes precedence

## Pointers

- See `lib/api-spec/openapi.yaml` for the full API contract
- See `.local/skills/pnpm-workspace` for workspace structure and TypeScript setup
